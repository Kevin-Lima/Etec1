/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetocarlos;


public class Principal {
    public static void main(String[] args) {
        MenuComissao menu = new MenuComissao();
        menu.exibirMenuPrincipal();
    }
}
